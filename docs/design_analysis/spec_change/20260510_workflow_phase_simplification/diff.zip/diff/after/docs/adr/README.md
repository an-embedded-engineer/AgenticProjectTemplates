# ADR Index

## 1. 目的

このディレクトリは、プロジェクトで採用済みの横断的アーキテクチャ判断を、Agent と開発者が短時間で再参照するための薄い索引層である。案件ごとの詳細経緯や検討過程は `docs/design_analysis/` に残し、ADR では「何を採用済み判断として固定しているか」と「どの文書を根拠として参照すべきか」を短く示す。

## 2. 起票条件

次のすべてを満たす判断だけを ADR として追加する。

1. 既にこのリポジトリで採用済みである
2. 複数案件で再利用される可能性が高い
3. 誤ると同種の設計ミスを繰り返しやすい
4. `docs/rules/coding_rules.md` だけでは背景や適用条件が不足する

次は ADR の対象外とする。

- 案件固有の詳細設計
- テスト手順やレビュー応答
- 未採用の将来案や speculative な仕様変更候補

## 3. 責務分担

- `docs/adr/`: 採用済み判断の短い索引
- `docs/design_analysis/`: 案件ごとの背景、比較、検討履歴、レビュー反映
- `docs/rules/coding_rules.md`: 常設ルールと実装時の一般原則

ADR は `design_analysis` の代替ではない。判断の詳細な根拠、代替案比較、レビュー応答は既存文書へリンクする。

## 4. 参照ルール

- 関連 ADR が存在する場合のみ、計画前・実装前・レビュー時に参照する
- 関連性判定は本 README の一覧と索引規則で行う
- 常に全 ADR を読む運用は採らない

## 5. 索引規則

次の 3 軸で関連 ADR の有無を判定する。

1. topic
   - 課題の主要テーマが既存 ADR の topic と一致するか
2. component
   - 変更対象の package、module、layer、外部境界が既存 ADR の対象 component に触れるか
3. keyword
   - 計画や設計の主題に、既存 ADR の keywords が含まれるか

複数軸のいずれかで一致した場合は、該当 ADR を先に確認する。

## 6. ADR 一覧

初期状態では seed ADR を置かない。プロジェクト適用後、採用済みの横断判断が起票条件を満たした時に `_template.md` から追加する。

| ADR | topic | component | keywords |
|---|---|---|---|
| [ADR-0001](0001_workflow_phase_simplification.md) | workflow phase simplification | user-agent-assets/skills, docs/design_analysis | workflow, phase, review, completion, wbs, related_commits |

## 7. 追加方針

- 新しい ADR を追加したくなった場合、同時に多数追加せず、必要性が独立しているなら別 issue / TODO へ分離する
- 索引規則の改善やカタログ整理が必要になった場合も、個別 follow-up として扱う

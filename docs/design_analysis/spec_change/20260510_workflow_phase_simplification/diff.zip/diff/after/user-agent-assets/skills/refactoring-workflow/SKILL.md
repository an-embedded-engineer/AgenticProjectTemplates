---
name: refactoring-workflow
description: プロジェクトのリファクタリングで、対象整理、設計、レビュー、実装、振る舞い不変確認、文書反映、完了処理までを行う手順。
---

# refactoring-workflow

## いつ使う

- 外部仕様を変えずに内部構造を整理する時

## 実行ルール（索引）

- 手順本体: `references/procedure/refactoring_workflow.md`
- workflow 選択: workflow 判定ルール
- レビュー観点詳細: `ai-review-response-workflow` skill に同梱された `references/procedure/review_checkpoints.md`
- 共通ルール: `各プロジェクトのコーディング規約`
- 実行コマンド: `各プロジェクトの開発・検証コマンド定義`

## 禁止事項

- Phase 0（対象整理）と Phase 1（ブランチ作成）を飛ばして Phase 2 以降に進んではならない
- 仕様変更を混ぜ込んではならない
- ユーザ承認なしに次の Phase に進んではならない
- レビュー文書（`*_review.md`）を自分で作成してはならない

## 最低限の必須チェック

1. Phase 0 で振る舞い不変条件と改善対象を定義する
2. `docs/todo/todo.md` に対象項目を記録する
3. Phase 1 で専用ブランチと `meta.md` を作成する
4. Phase 2 の設計で現状の構造問題と分割戦略を明記する
5. 実装記録に振る舞い不変の確認結果を残す
6. 対象プロジェクトで定義された検証コマンドを実行する
7. 設計文書は `design` / `impl` を中心に管理し、独立した `plan` 文書を標準成果物にしない
8. レビュー文書はレビュー担当 Agent が作成する
9. 恒久ドキュメントへ責務分割変更を反映する
10. Phase 4-b で差分レポート（`change_report.md`、ソース変更を含む場合は `diff.zip`）を生成してコミットする
11. 完了時は `todo_archive_<year>.md` へ移し、各 STOP ゲートで承認を待つ
